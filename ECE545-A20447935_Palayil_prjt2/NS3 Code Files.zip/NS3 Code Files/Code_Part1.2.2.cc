#include <string> 
#include <fstream> 
#include <cassert> 
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/internet-module.h"
#include "ns3/netanim-module.h"
#include "ns3/packet-sink.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/tcp-socket-base.h"
#include "ns3/traffic-control-module.h"
#include "ns3/rtt-estimator.h"
#include "ns3/error-model.h"
#include "ns3/animation-interface.h"

using namespace ns3;
using namespace std;

#define ERROR_P 0.001

NS_LOG_COMPONENT_DEFINE("545_prjt2_part1.2.2_final");

static bool firstRtt = true;
static bool firstRto = true;
static Ptr<OutputStreamWrapper> rttStream;
static Ptr<OutputStreamWrapper> rtoStream;
static Ptr<RttMeanDeviation> rttE = CreateObject<RttMeanDeviation> ();

class App : public Application
{
public:
  App (); 
  virtual ~App(); 
  void Setup (Ptr<Socket> socket, Address address, uint32_t packetSize,uint32_t nPackets, DataRate dataRate);

private:
  virtual void StartApplication(void);
  virtual void StopApplication(void);
  void ScheduleTx(void);
  void SendPacket(void);
  Ptr<Socket> m_socket;
  Address m_peer;
  uint32_t m_packetSize;
  uint32_t m_nPackets;
  DataRate m_dataRate;
  EventId m_sendEvent;
  bool m_running;
  uint32_t m_packetsSent;
};

App::App()
  : m_socket(0),
    m_peer(),
    m_packetSize(0),
    m_nPackets(0),
    m_dataRate(0),
    m_sendEvent(),
    m_running(false),
    m_packetsSent(0)
{}

App::~App() 
{
  m_socket = 0;
}

void App::Setup(Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate) 
{
  m_socket = socket;
  m_peer = address;
  m_packetSize = packetSize;
  m_nPackets = nPackets;
  m_dataRate = dataRate;
}

void App::StartApplication(void) 
{
  m_running = true;
  m_packetsSent = 0;
  m_socket->Bind();
  m_socket->Connect(m_peer);
  SendPacket();
}

void App::StopApplication(void) 
{
  m_running = false;
  if (m_sendEvent.IsRunning()) 
  {
    Simulator::Cancel(m_sendEvent);
  }
  if (m_socket) 
  {
    m_socket->Close();
  }
}

void App::SendPacket(void) 
{
  Ptr<Packet> packet = Create<Packet>(m_packetSize);
  m_socket->Send(packet);
  if (++m_packetsSent < m_nPackets) 
  {
    ScheduleTx();
  }
}

void App::ScheduleTx(void) 
{
  if (m_running) 
  {
    Time tNext(Seconds(m_packetSize * 8 / static_cast<double>(m_dataRate.GetBitRate())));
    m_sendEvent = Simulator::Schedule(tNext, &App::SendPacket, this);
  }
}

static void CwndChange (uint32_t oldCwnd, uint32_t newCwnd)
{
  std::cout << Simulator::Now ().GetSeconds () << "\t" << newCwnd <<"\n";
}

static void RttTracer (Time oldval, Time newval)
{
  if (firstRtt)
    {
      *rttStream->GetStream () << "0.0 " << oldval.GetSeconds () << std::endl;
      firstRtt = false;
    }
   rttE->Measurement (newval); 
   *rttStream->GetStream () << Simulator::Now ().GetSeconds () << "\t" << newval.GetSeconds () << "\t" << rttE->GetEstimate().GetSeconds () << std::endl;
}

static void RtoTracer (Time oldval, Time newval)
{
  if (firstRto)
    {
      *rtoStream->GetStream () << "0.0 " << oldval.GetSeconds () << std::endl;
      firstRto = false;
    }
  *rtoStream->GetStream () << Simulator::Now ().GetSeconds () << "\t" << newval.GetSeconds () << std::endl;
}

// Main function 
int main (int argc, char *argv[]) 
{
  uint32_t packetSize=1400;
  uint32_t nPackets=200000;
  
  // TCP setting
  Config::SetDefault ("ns3::TcpL4Protocol::SocketType", StringValue("ns3::TcpNewReno"));
  Config::SetDefault("ns3::TcpSocket::SegmentSize", UintegerValue (1000));
  Config::SetDefault("ns3::TcpSocket::InitialCwnd", UintegerValue (1));
  Config::SetDefault("ns3::TcpSocketBase::MaxWindowSize", UintegerValue (20*packetSize));
  Config::SetDefault ("ns3::TcpSocket::RcvBufSize", UintegerValue (1 << 21));

  //RTT estinamtor setting
  Config::SetDefault ("ns3::RttEstimator::InitialEstimation", TimeValue (MilliSeconds (500)));
  Config::SetDefault ("ns3::RttMeanDeviation::Alpha", DoubleValue (0.5));
  Config::SetDefault ("ns3::RttMeanDeviation::Beta", DoubleValue (0.6));
  NS_LOG_COMPONENT_DEFINE("545_prjt2_part1.2.2");

  // Create Nodes.
  NodeContainer nodes;
  nodes.Create(4);

  // Define node containers for point-to-point links
  NodeContainer n1n3 = NodeContainer(nodes.Get(0), nodes.Get(1));
  NodeContainer n3n4 = NodeContainer(nodes.Get(1), nodes.Get(2));
  NodeContainer n4n5 = NodeContainer(nodes.Get(2), nodes.Get(3));
  
  // Equipped IP/TCP/UDP for nodes
  InternetStackHelper internet;
  internet.Install(nodes);
  
  //Create a uniform random variable object em:
  Ptr<UniformRandomVariable> em = CreateObject<UniformRandomVariable> ();

  // Specify the stream number for the random stream
  em->SetStream (50);
  RateErrorModel ERROR;

  // Generate error model
  ERROR.SetRandomVariable (em);
  ERROR.SetRate (ERROR_P);
  ERROR.SetUnit (RateErrorModel::ERROR_UNIT_PACKET);//BIT BYTE
  NS_LOG_INFO ("Create Channels.");
  
  // Define point-to-point links
  PointToPointHelper p2pHR, p2pRR;
  p2pHR.SetDeviceAttribute("DataRate", StringValue("3Mbps"));
  p2pHR.SetChannelAttribute("Delay", StringValue("10ms"));
  p2pRR.SetDeviceAttribute("DataRate", StringValue("1.5Mbps"));
  p2pRR.SetChannelAttribute("Delay", StringValue("10ms"));
  
  // Install devices on point-to-point links
  NetDeviceContainer d1d3 = p2pHR.Install(n1n3);
  NetDeviceContainer d3d4 = p2pRR.Install(n3n4);
  NetDeviceContainer d4d5 = p2pHR.Install(n4n5);
  
  // Assign IP addresses to nodes
  NS_LOG_INFO("Assign IP Addresses.");
  Ipv4AddressHelper ipv4;
  ipv4.SetBase ("10.1.1.0", "255.255.255.0");
  Ipv4InterfaceContainer i1i3 = ipv4.Assign (d1d3);
  ipv4.SetBase ("10.1.2.0", "255.255.255.0");
  Ipv4InterfaceContainer i3i4 = ipv4.Assign (d3d4);
  ipv4.SetBase ("10.1.3.0", "255.255.255.0");
  Ipv4InterfaceContainer i4i5 = ipv4.Assign (d4d5);

  // Uninstall traffic control
  TrafficControlHelper tc;
  tc.Uninstall (d1d3);
  tc.Uninstall (d3d4);
  tc.Uninstall (d4d5);

  // Populate routing tables
  Ipv4GlobalRoutingHelper::PopulateRoutingTables ();
  NS_LOG_INFO ("Create Applications.");
  
  // FTP port number (RFC 863 USING 9)
  uint16_t port = 21;
  
  // Install server application
  PacketSinkHelper sinkHelper ("ns3::TcpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), port));
  ApplicationContainer sinkApp = sinkHelper.Install(nodes.Get(3));
  sinkApp.Start (Seconds (0.0));
  sinkApp.Stop (Seconds (51.0));

  // Install client application
  Ptr<Socket> socket = Socket::CreateSocket (nodes.Get(0), TcpSocketFactory::GetTypeId ());
  Ptr<App> clientApp = CreateObject<App> ();

  // Address for client and server
  Ipv4Address clientAddress = i1i3.GetAddress (0);
  AddressValue localAddress (InetSocketAddress (clientAddress, port));
  Ipv4Address serverAddress = i4i5.GetAddress (1);
  Address remoteAddress (InetSocketAddress (serverAddress, port));
  clientApp->Setup(socket, remoteAddress, packetSize,nPackets, DataRate("10Mbps"));
  nodes.Get (0)->AddApplication(clientApp);
  clientApp->SetStartTime(Seconds(1.0));
  clientApp->SetStopTime(Seconds(51.0));
  
  // Enable ASCII trace output
  AsciiTraceHelper ascii;
  p2pRR.EnableAsciiAll (ascii.CreateFileStream ("scratch/Part1.2.2.tr"));

  // Trace Congestion window and output to "CongestionWindow.txt" file
  rttStream = ascii.CreateFileStream ("scratch/CongestionWindow1.2.2.txt");  
  socket->TraceConnectWithoutContext ("CongestionWindow", MakeCallback (&CwndChange));

  // Trace RTT, estimate RTT and output to "RTT.txt" file
  rttStream = ascii.CreateFileStream ("scratch/RTT1.2.2.txt");
  socket->TraceConnectWithoutContext ("RTT", MakeCallback (&RttTracer));

  // Trace RTO and output to "RTO.txt" file
  rtoStream = ascii.CreateFileStream ("scratch/RTO1.2.2.txt");
  socket->TraceConnectWithoutContext ("RTO", MakeCallback (&RtoTracer));

  // Calculate Throughput using Flowmonitor
  FlowMonitorHelper flowmon;
  Ptr<FlowMonitor> monitor = flowmon.InstallAll();
  NS_LOG_INFO ("Run Simulation.");
  Simulator::Stop (Seconds(52));
  Simulator::Run ();
  NS_LOG_INFO ("Done.");
  monitor->CheckForLostPackets ();
  Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier> (flowmon.GetClassifier ());
  std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats ();
  std::cout << std::endl << "### Results Error Rate 0.001 ###" << std::endl;
  std::cout << " Transmitted Bytes: " << stats[1].txBytes << std::endl;
  std::cout << " Received Bytes: " << stats[1].rxBytes << std::endl;
  std::cout << " Transmitted Packets: " << stats[1].txPackets << std::endl;
  std::cout << " Receive Packets: " << stats[1].rxPackets << std::endl;
  std::cout << " Packetloss rate: " << ((stats[1].txPackets * 1.0 - stats[1].rxPackets) / stats[1].txPackets ) << std::endl; 
  std::cout << " Throughput: " << stats[1].rxBytes * 8.0 / (stats[1].timeLastRxPacket.GetSeconds()-stats[1].timeFirstRxPacket.GetSeconds())/ 1000000 << " Mbps" << std::endl;
  Simulator::Destroy ();
}
