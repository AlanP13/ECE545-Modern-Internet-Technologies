#include <string> 
#include <fstream> 
#include <cassert> 
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/animation-interface.h"
#include "ns3/internet-module.h"
#include "ns3/netanim-module.h"
#include "ns3/packet-sink.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/tcp-socket-base.h"
#include "ns3/traffic-control-module.h"
#include "ns3/rtt-estimator.h"
#include "ns3/double.h"

using namespace ns3;
using namespace std;

#define simtime 51
//Modify the value for fair-share
#define UDPdatarate "0.725Mbps"

NS_LOG_COMPONENT_DEFINE ("545_prjt2_part2.1.2_final"); 

static bool firstRtt = true;
static bool firstRto = true;
static Ptr<OutputStreamWrapper> rttStream;
static Ptr<OutputStreamWrapper> rtoStream;
static Ptr<RttMeanDeviation> rttE = CreateObject<RttMeanDeviation> ();
static Ptr<OutputStreamWrapper> thrStream;

class TcpApp : public Application
{
public:
  TcpApp (); 
  virtual ~TcpApp(); 
  void Setup (Ptr<Socket> socket, Address address, uint32_t packetSize,uint32_t nPackets, DataRate dataRate);

private:
  virtual void StartApplication (void); 
  virtual void StopApplication (void);  
  void ScheduleTx (void); 
  void SendPacket (void); 
  Ptr<Socket>     m_socket;
  Address         m_peer;  
  uint32_t        m_packetSize;
  uint32_t        m_nPackets; 
  DataRate        m_dataRate;  
  EventId         m_sendEvent; 
  bool            m_running; 
  uint32_t        m_packetsSent;
};

TcpApp::TcpApp ()
   : m_socket (0),
    m_peer (),
    m_packetSize (0),
    m_nPackets (0),
    m_dataRate (0),
    m_sendEvent (),
    m_running (false),
    m_packetsSent (0)
{}

TcpApp::~TcpApp()
{
  m_socket = 0;
}

void TcpApp::Setup (Ptr<Socket> socket, Address address, uint32_t packetSize,uint32_t nPackets,DataRate dataRate)
{
  m_socket = socket; 
  m_peer = address;
  m_packetSize = packetSize;
  m_nPackets = nPackets;
  m_dataRate = dataRate;
}

void TcpApp::StartApplication (void)
{
  m_running = true;
  m_packetsSent = 0;
  m_socket->Bind (); 
  m_socket->Connect (m_peer); 
  SendPacket (); 
}

void TcpApp::StopApplication (void)
{
  m_running = false;
  if (m_sendEvent.IsRunning ()) 
    {
      Simulator::Cancel (m_sendEvent); 
    }
  if (m_socket)  
    {
      m_socket->Close ();
    }
}

void TcpApp::SendPacket (void)
{
  Ptr<Packet> packet = Create<Packet> (m_packetSize);
  m_socket->Send (packet); 
  if (++m_packetsSent < m_nPackets) 
    {
      ScheduleTx (); 
    }
}

void TcpApp::ScheduleTx (void)
{
  if (m_running) 
    {
      Time tNext (Seconds (m_packetSize * 8 / static_cast<double> (m_dataRate.GetBitRate ())));
      m_sendEvent = Simulator::Schedule (tNext, &TcpApp::SendPacket, this);
    }
}

static void RttTracer (Time oldval, Time newval)
{
  if (firstRtt)
    {
      *rttStream->GetStream () << "0.0 " << oldval.GetSeconds () << std::endl;
      firstRtt = false;
    }
   rttE->Measurement (newval);
   *rttStream->GetStream () << Simulator::Now ().GetSeconds () << "\t" << newval.GetSeconds () << "\t" << rttE->GetEstimate().GetSeconds () << std::endl;
}

static void RtoTracer (Time oldval, Time newval)
{
  if (firstRto)
    {
      *rtoStream->GetStream () << "0.0 " << oldval.GetSeconds () << std::endl;
      firstRto = false;
    }
  *rtoStream->GetStream () << Simulator::Now ().GetSeconds () << "\t" << newval.GetSeconds () << std::endl;
}

void throughput(Ptr<FlowMonitor> monitor, FlowMonitorHelper* flowmon) 
{
    monitor->CheckForLostPackets ();
    Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier> (flowmon->GetClassifier ());
    std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats ();
    for (std::map<FlowId, FlowMonitor::FlowStats>::const_iterator i = stats.begin (); i != stats.end (); ++i)
    {
       Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow (i->first);
       std::cout << "Flow " << i->first  << " (" << t.sourceAddress << " -> " << t.destinationAddress << ") - "<<"\n";    
       double Throughput = i->second.rxBytes * 8.0 / (i->second.timeLastRxPacket.GetSeconds()- i->second.timeFirstTxPacket.GetSeconds()) /1000000;
          std::cout << "Instantaneous Throughput: " << Throughput << " Mbps\n";
      if(t.sourceAddress == "10.1.1.1")
      {
        *thrStream->GetStream () << Simulator::Now ().GetSeconds () << "\t" << Throughput ;
      }
      if(t.sourceAddress == "10.1.4.1")
      {
        *thrStream->GetStream () << "\t" << Throughput << std::endl;
      }
    } 
    Simulator::Schedule(Seconds(1.0), &throughput, monitor, flowmon);
}

// Main function 
int main (int argc, char *argv[])
{  
  uint32_t packetSize=1400;
  uint32_t nPackets=200000;

  // TCP setting
  Config::SetDefault ("ns3::TcpL4Protocol::SocketType", StringValue("ns3::TcpNewReno"));
  Config::SetDefault("ns3::TcpSocket::SegmentSize", UintegerValue (1000));
  Config::SetDefault("ns3::TcpSocket::InitialCwnd", UintegerValue (1));
  Config::SetDefault("ns3::TcpSocketBase::MaxWindowSize", UintegerValue (20*1000));
  Config::SetDefault ("ns3::TcpSocket::RcvBufSize", UintegerValue (1 << 21));
  
  //RTT estinamtor setting
  Config::SetDefault ("ns3::RttEstimator::InitialEstimation", TimeValue (MilliSeconds (500)));
  Config::SetDefault ("ns3::RttMeanDeviation::Alpha", DoubleValue (0.5));
  Config::SetDefault ("ns3::RttMeanDeviation::Beta", DoubleValue (0.6));
  
  // Create Nodes.
  NodeContainer nodes;
  nodes.Create (6);
  
  // Define node containers for point-to-point links
  NodeContainer n1n3 = NodeContainer (nodes.Get (0), nodes.Get (1));
  NodeContainer n3n4 = NodeContainer (nodes.Get (1), nodes.Get (2));
  NodeContainer n4n5 = NodeContainer (nodes.Get (2), nodes.Get (3));
  NodeContainer n2n3 = NodeContainer (nodes.Get (4), nodes.Get (1));
  NodeContainer n4n6 = NodeContainer (nodes.Get (2), nodes.Get (5));
  
  //Equipped IP/TCP/UDP for nodes
  InternetStackHelper internet;
  internet.Install (nodes);
  NS_LOG_INFO ("Create Channels.");

  // Define point-to-point links
  PointToPointHelper p2pHR, p2pRR;
  p2pHR.SetDeviceAttribute("DataRate",StringValue("3Mbps"));
  p2pHR.SetChannelAttribute ("Delay", StringValue ("10ms"));
  p2pRR.SetDeviceAttribute("DataRate",StringValue("1.5Mbps"));
  p2pRR.SetChannelAttribute ("Delay", StringValue ("10ms"));
  
  //Install attributes to nodes
  NetDeviceContainer d1d3=p2pHR.Install(n1n3);
  NetDeviceContainer d3d4=p2pRR.Install(n3n4);
  NetDeviceContainer d4d5=p2pHR.Install(n4n5);
  NetDeviceContainer d2d3=p2pHR.Install(n2n3);
  NetDeviceContainer d4d6=p2pHR.Install(n4n6);
  
  // Assign IP addresses to nodes
  NS_LOG_INFO ("Assign IP Address5s.");
  Ipv4AddressHelper ipv4;
  ipv4.SetBase ("10.1.1.0", "255.255.255.0");
  Ipv4InterfaceContainer i1i3 = ipv4.Assign (d1d3);
  ipv4.SetBase ("10.1.2.0", "255.255.255.0");
  Ipv4InterfaceContainer i3i4 = ipv4.Assign (d3d4);
  ipv4.SetBase ("10.1.3.0", "255.255.255.0");
  Ipv4InterfaceContainer i4i5 = ipv4.Assign (d4d5);
  ipv4.SetBase ("10.1.4.0", "255.255.255.0");
  Ipv4InterfaceContainer i2i3 = ipv4.Assign (d2d3);
  ipv4.SetBase ("10.1.5.0", "255.255.255.0");
  Ipv4InterfaceContainer i4i6 = ipv4.Assign (d4d6);

  // Uninstall traffic control
  TrafficControlHelper tc;
  tc.Uninstall (d1d3);
  tc.Uninstall (d3d4);
  tc.Uninstall (d4d5);
  tc.Uninstall (d2d3);
  tc.Uninstall (d4d6);
  NS_LOG_INFO ("Enable static global routing.");
  Ipv4GlobalRoutingHelper::PopulateRoutingTables ();

  // TCP connection setting
  uint16_t port = 21;
  
  // Install server application
  ApplicationContainer sinkApp;
  Address sinkLocalAddress(InetSocketAddress (Ipv4Address::GetAny (), port));
  PacketSinkHelper sinkHelper ("ns3::TcpSocketFactory", sinkLocalAddress);
  sinkApp=sinkHelper.Install(nodes.Get(3));    
  sinkApp.Start (Seconds (0.));
  sinkApp.Stop (Seconds (simtime));

  // Install client application
  Ptr<Socket> Socket1 = Socket::CreateSocket (nodes.Get (0), TcpSocketFactory::GetTypeId ());
  Ptr<TcpApp> clientApp = CreateObject<TcpApp>();

  // Address for client1 and server1
  Ipv4Address clientAddress1 = i1i3.GetAddress (0);
  AddressValue localAddress1 (InetSocketAddress (clientAddress1, port));
  Ipv4Address serverAddress1 = i4i5.GetAddress (1);
  Address remoteAddress1 (InetSocketAddress (serverAddress1, port));
  clientApp->Setup(Socket1, remoteAddress1, packetSize,nPackets, DataRate("10Mbps"));
  nodes.Get (0)->AddApplication(clientApp);
  clientApp->SetStartTime(Seconds(1.0));
  clientApp->SetStopTime(Seconds(simtime));
  
  //UDP setup
  Address localAddress (InetSocketAddress (Ipv4Address::GetAny (), port));
  PacketSinkHelper packetSinkHelper ("ns3::UdpSocketFactory", localAddress);

  // CBR traffic generate
  OnOffHelper onoff ("ns3::UdpSocketFactory", Ipv4Address::GetAny ());
  onoff.SetAttribute ("OnTime",  StringValue ("ns3::ConstantRandomVariable[Constant=1]"));
  onoff.SetAttribute ("OffTime", StringValue ("ns3::ConstantRandomVariable[Constant=0]"));
  
  // Traffic generation rate
  onoff.SetAttribute ("DataRate", StringValue (UDPdatarate)); 
  ApplicationContainer apps;
  AddressValue remoteAddress(InetSocketAddress (i4i5.GetAddress(1), port));
  onoff.SetAttribute ("Remote", remoteAddress);
  apps.Add(onoff.Install(nodes.Get(4)));  

  // Set time range for sink node to start and stop application
  apps.Start (Seconds (1.));
  apps.Stop (Seconds (simtime));
  sinkApp.Start (Seconds (0.));
  sinkApp.Stop (Seconds (simtime));
  
  // Enable ASCII trace output
  AsciiTraceHelper ascii;
  p2pRR.EnableAsciiAll (ascii.CreateFileStream ("scratch/Part2.1.2.tr"));
  
  // Trace RTT, estimate RTT and output to "RTT.txt" file
  rttStream = ascii.CreateFileStream ("scratch/RTT2.1.2.txt");
  Socket1->TraceConnectWithoutContext ("RTT", MakeCallback (&RttTracer));

  // Trace RTO and output to "RTO.txt" file
  rtoStream = ascii.CreateFileStream ("scratch/RTO2.1.2.txt");
  Socket1->TraceConnectWithoutContext ("RTO", MakeCallback (&RtoTracer));

  // Trace Throughput and output to "Throughput.txt" file
  thrStream = ascii.CreateFileStream ("scratch/Throughput2.1.2.txt");
  Socket1->TraceConnectWithoutContext ("throughput", MakeCallback (&throughput));

  // Calculate Throughput using Flowmonitor
  FlowMonitorHelper flowmon;
  Ptr<FlowMonitor> monitor = flowmon.InstallAll();
  NS_LOG_INFO ("Run Simulation.");
  Simulator::Stop (Seconds(simtime+1));
  Simulator::Schedule(Seconds(1.0), &throughput, monitor, &flowmon);
  Simulator::Run ();
  monitor->CheckForLostPackets ();
  Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier> (flowmon.GetClassifier ());
  std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats ();
  std::cout << std::endl << "### Results for TCP/UDP using CBR ###" << std::endl;
  for (std::map<FlowId, FlowMonitor::FlowStats>::const_iterator i = stats.begin (); i != stats.end (); ++i)
    {
      std::cout << "  Flow " << i->first  << "\n";
      std::cout << "  Transmitted Bytes: " << i->second.txBytes << std::endl;
      std::cout << "  Received Bytes: " << i->second.rxBytes << std::endl;
      std::cout << "  Transmitted Packets: " << i->second.txPackets << std::endl;
      std::cout << "  Receive Packets: " << i->second.rxPackets << std::endl;
      std::cout << "  Packetloss rate: " << ((i->second.txPackets * 1.0 - i->second.rxPackets) / i->second.txPackets ) << std::endl;
      std::cout << "  Throughput: " << i->second.rxBytes * 8.0 / (i->
      second.timeLastRxPacket.GetSeconds()-i->second.timeFirstRxPacket.GetSeconds())/ 1000000 << " Mbps" << std::endl;
    }
    Simulator::Destroy ();
 }
